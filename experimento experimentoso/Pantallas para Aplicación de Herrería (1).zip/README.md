
  # Pantallas para Aplicación de Herrería

  This is a code bundle for Pantallas para Aplicación de Herrería. The original project is available at https://www.figma.com/design/AF71VW67gvcJ0uRbQIKzxe/Pantallas-para-Aplicaci%C3%B3n-de-Herrer%C3%ADa.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  